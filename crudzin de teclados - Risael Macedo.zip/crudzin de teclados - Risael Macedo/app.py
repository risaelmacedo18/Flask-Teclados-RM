from flask import Flask, render_template, request, url_for, redirect
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__, template_folder='templates')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///teclados.sqlite3'

db = SQLAlchemy(app)


class Teclado(db.Model):
    id = db.Column('id', db.Integer, primary_key=True, autoincrement=True)
    nome = db.Column(db.String(150))
    valor = db.Column(db.Integer)

    def __init__(self, nome, valor):
        self.nome = nome
        self.valor = valor
 

@app.route('/')
def index():
    teclados = Teclado.query.all()
    return render_template('index.html', teclados=teclados)


@app.route('/add', methods=['GET', 'POST'])
def add():
    if request.method == 'POST':
        teclado = Teclado(request.form['nome'], request.form['valor'])
        db.session.add(teclado)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add.html')


@app.route('/edit/<int:id>', methods=['GET', 'POST'])
def edit(id):
    teclado = Teclado.query.get(id)
    if request.method == 'POST':
        teclado.nome = request.form['nome']
        teclado.valor = request.form['valor']
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('edit.html', teclado=teclado)


@app.route('/delete/<int:id>')
def delete(id):
    teclado = Teclado.query.get(id)
    db.session.delete(teclado)
    db.session.commit()
    return redirect(url_for('index'))


if __name__ == '__main__':
    db.create_all()
    app.run(debug=True)
